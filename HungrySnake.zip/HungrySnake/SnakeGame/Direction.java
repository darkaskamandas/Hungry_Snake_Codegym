package com.codegym.games.snake;

public enum Direction {
    UP,
    RIGHT,
    DOWN,
    LEFT
}